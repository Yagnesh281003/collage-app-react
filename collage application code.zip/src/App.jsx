import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import Profile from './pages/Profile';
import Property1Default from './pages/Property1Default';
import Property1Default1 from './pages/Property1Default1';
import Property1Default2 from './pages/Property1Default2';
import Property1Default3 from './pages/Property1Default3';
import Property1Default4 from './pages/Property1Default4';
import Property1Default5 from './pages/Property1Default5';
import Property1Default6 from './pages/Property1Default6';
import Property1Default7 from './pages/Property1Default7';
import Property1Default8 from './pages/Property1Default8';
import Property1Tick from './pages/Property1Tick';
import Property1Variant2 from './pages/Property1Variant2';
import Property1Variant21 from './pages/Property1Variant21';
import Property1Variant22 from './pages/Property1Variant22';
import Property1Variant23 from './pages/Property1Variant23';
import Property1Variant24 from './pages/Property1Variant24';
import Property1Variant25 from './pages/Property1Variant25';
import Property1Variant26 from './pages/Property1Variant26';
import Property1Variant27 from './pages/Property1Variant27';
import Property1Variant28 from './pages/Property1Variant28';
import Property1Variant3 from './pages/Property1Variant3';
import Property1Variant31 from './pages/Property1Variant31';
import Property1Variant32 from './pages/Property1Variant32';
import Property1Variant4 from './pages/Property1Variant4';
import Property1Variant41 from './pages/Property1Variant41';
import StudentAttendance from './pages/StudentAttendance';
import StudentChat from './pages/StudentChat';
import StudentDashboard1 from './pages/StudentDashboard1';
import StudentFirstPage from './pages/StudentFirstPage';
import StudentLoginPage from './pages/StudentLoginPage';
import StudentMenu from './pages/StudentMenu';
import StudentNotes1 from './pages/StudentNotes1';
import StudentNotesPage from './pages/StudentNotesPage';
import StudentPeople from './pages/StudentPeople';
import StudentProfilePage from './pages/StudentProfilePage';
import StudentResults from './pages/StudentResults';
import StudentSearch from './pages/StudentSearch';
import StudentSignup from './pages/StudentSignup';
import StudentStream from './pages/StudentStream';
import StudentSubmissionPage from './pages/StudentSubmissionPage';
import StudentTools from './pages/StudentTools';
import TeacherAddButtonInNotes from './pages/TeacherAddButtonInNotes';
import TeacherAttendance from './pages/TeacherAttendance';
import TeacherChat from './pages/TeacherChat';
import TeacherClassroom from './pages/TeacherClassroom';
import TeacherDashboard1 from './pages/TeacherDashboard1';
import TeacherFirstPage from './pages/TeacherFirstPage';
import TeacherLoginPage from './pages/TeacherLoginPage';
import TeacherMenu from './pages/TeacherMenu';
import TeacherNotes1 from './pages/TeacherNotes1';
import TeacherNotesPage from './pages/TeacherNotesPage';
import TeacherPeople from './pages/TeacherPeople';
import TeacherPost from './pages/TeacherPost';
import TeacherPost1 from './pages/TeacherPost1';
import TeacherProfilePage from './pages/TeacherProfilePage';
import TeacherSearch from './pages/TeacherSearch';
import TeacherSignup from './pages/TeacherSignup';
import TeacherStream from './pages/TeacherStream';
import TeacherStreamUploadPage from './pages/TeacherStreamUploadPage';
import TeacherSubmissionPage from './pages/TeacherSubmissionPage';
import TeacherTools from './pages/TeacherTools';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/Profile', element: <Profile /> },
{ path: '/Property1Default', element: <Property1Default /> },
{ path: '/Property1Default1', element: <Property1Default1 /> },
{ path: '/Property1Default2', element: <Property1Default2 /> },
{ path: '/Property1Default3', element: <Property1Default3 /> },
{ path: '/Property1Default4', element: <Property1Default4 /> },
{ path: '/Property1Default5', element: <Property1Default5 /> },
{ path: '/Property1Default6', element: <Property1Default6 /> },
{ path: '/Property1Default7', element: <Property1Default7 /> },
{ path: '/Property1Default8', element: <Property1Default8 /> },
{ path: '/Property1Tick', element: <Property1Tick /> },
{ path: '/Property1Variant2', element: <Property1Variant2 /> },
{ path: '/Property1Variant21', element: <Property1Variant21 /> },
{ path: '/Property1Variant22', element: <Property1Variant22 /> },
{ path: '/Property1Variant23', element: <Property1Variant23 /> },
{ path: '/Property1Variant24', element: <Property1Variant24 /> },
{ path: '/Property1Variant25', element: <Property1Variant25 /> },
{ path: '/Property1Variant26', element: <Property1Variant26 /> },
{ path: '/Property1Variant27', element: <Property1Variant27 /> },
{ path: '/Property1Variant28', element: <Property1Variant28 /> },
{ path: '/Property1Variant3', element: <Property1Variant3 /> },
{ path: '/Property1Variant31', element: <Property1Variant31 /> },
{ path: '/Property1Variant32', element: <Property1Variant32 /> },
{ path: '/Property1Variant4', element: <Property1Variant4 /> },
{ path: '/Property1Variant41', element: <Property1Variant41 /> },
{ path: '/StudentAttendance', element: <StudentAttendance /> },
{ path: '/StudentChat', element: <StudentChat /> },
{ path: '/StudentDashboard1', element: <StudentDashboard1 /> },
{ path: '/StudentFirstPage', element: <StudentFirstPage /> },
{ path: '/StudentLoginPage', element: <StudentLoginPage /> },
{ path: '/StudentMenu', element: <StudentMenu /> },
{ path: '/StudentNotes1', element: <StudentNotes1 /> },
{ path: '/StudentNotesPage', element: <StudentNotesPage /> },
{ path: '/StudentPeople', element: <StudentPeople /> },
{ path: '/StudentProfilePage', element: <StudentProfilePage /> },
{ path: '/StudentResults', element: <StudentResults /> },
{ path: '/StudentSearch', element: <StudentSearch /> },
{ path: '/StudentSignup', element: <StudentSignup /> },
{ path: '/StudentStream', element: <StudentStream /> },
{ path: '/StudentSubmissionPage', element: <StudentSubmissionPage /> },
{ path: '/StudentTools', element: <StudentTools /> },
{ path: '/TeacherAddButtonInNotes', element: <TeacherAddButtonInNotes /> },
{ path: '/TeacherAttendance', element: <TeacherAttendance /> },
{ path: '/TeacherChat', element: <TeacherChat /> },
{ path: '/TeacherClassroom', element: <TeacherClassroom /> },
{ path: '/TeacherDashboard1', element: <TeacherDashboard1 /> },
{ path: '/TeacherFirstPage', element: <TeacherFirstPage /> },
{ path: '/TeacherLoginPage', element: <TeacherLoginPage /> },
{ path: '/TeacherMenu', element: <TeacherMenu /> },
{ path: '/TeacherNotes1', element: <TeacherNotes1 /> },
{ path: '/TeacherNotesPage', element: <TeacherNotesPage /> },
{ path: '/TeacherPeople', element: <TeacherPeople /> },
{ path: '/TeacherPost', element: <TeacherPost /> },
{ path: '/TeacherPost1', element: <TeacherPost1 /> },
{ path: '/TeacherProfilePage', element: <TeacherProfilePage /> },
{ path: '/TeacherSearch', element: <TeacherSearch /> },
{ path: '/TeacherSignup', element: <TeacherSignup /> },
{ path: '/TeacherStream', element: <TeacherStream /> },
{ path: '/TeacherStreamUploadPage', element: <TeacherStreamUploadPage /> },
{ path: '/TeacherSubmissionPage', element: <TeacherSubmissionPage /> },
{ path: '/TeacherTools', element: <TeacherTools /> },
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  );
}