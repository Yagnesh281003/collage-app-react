const tableHeaderStyle = {
  backgroundColor: "#f2f2f2",
  padding: 8,
  border: "1px solid #ddd",
}

const tableCellStyle = {
  padding: 8,
  border: "1px solid #ddd",
  color: "blue",
}

export default function F12Main() {
  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 20, fontSize: 20 }}>Page List</h1>
      <table style={{ borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr>
            <th style={tableHeaderStyle}>URL</th>
            <th style={tableHeaderStyle}>Page</th>
          </tr>
        </thead>
        <tbody>
<tr>
            <td style={tableCellStyle}><a href='/Profile'>/Profile</a></td>
            <td style={tableCellStyle}><a href='/Profile'>profile</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default'>/Property1Default</a></td>
            <td style={tableCellStyle}><a href='/Property1Default'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default1'>/Property1Default1</a></td>
            <td style={tableCellStyle}><a href='/Property1Default1'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default2'>/Property1Default2</a></td>
            <td style={tableCellStyle}><a href='/Property1Default2'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default3'>/Property1Default3</a></td>
            <td style={tableCellStyle}><a href='/Property1Default3'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default4'>/Property1Default4</a></td>
            <td style={tableCellStyle}><a href='/Property1Default4'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default5'>/Property1Default5</a></td>
            <td style={tableCellStyle}><a href='/Property1Default5'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default6'>/Property1Default6</a></td>
            <td style={tableCellStyle}><a href='/Property1Default6'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default7'>/Property1Default7</a></td>
            <td style={tableCellStyle}><a href='/Property1Default7'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default8'>/Property1Default8</a></td>
            <td style={tableCellStyle}><a href='/Property1Default8'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Tick'>/Property1Tick</a></td>
            <td style={tableCellStyle}><a href='/Property1Tick'>Property 1=Tick</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant2'>/Property1Variant2</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant2'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant21'>/Property1Variant21</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant21'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant22'>/Property1Variant22</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant22'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant23'>/Property1Variant23</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant23'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant24'>/Property1Variant24</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant24'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant25'>/Property1Variant25</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant25'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant26'>/Property1Variant26</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant26'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant27'>/Property1Variant27</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant27'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant28'>/Property1Variant28</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant28'>Property 1=Variant2</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant3'>/Property1Variant3</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant3'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant31'>/Property1Variant31</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant31'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant32'>/Property1Variant32</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant32'>Property 1=Variant3</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant4'>/Property1Variant4</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant4'>Property 1=Variant4</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Variant41'>/Property1Variant41</a></td>
            <td style={tableCellStyle}><a href='/Property1Variant41'>Property 1=Variant4</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentAttendance'>/StudentAttendance</a></td>
            <td style={tableCellStyle}><a href='/StudentAttendance'>Student Attendance</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentChat'>/StudentChat</a></td>
            <td style={tableCellStyle}><a href='/StudentChat'>Student chat</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentDashboard1'>/StudentDashboard1</a></td>
            <td style={tableCellStyle}><a href='/StudentDashboard1'>Student dashboard 1</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentFirstPage'>/StudentFirstPage</a></td>
            <td style={tableCellStyle}><a href='/StudentFirstPage'>Student first page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentLoginPage'>/StudentLoginPage</a></td>
            <td style={tableCellStyle}><a href='/StudentLoginPage'>Student login page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentMenu'>/StudentMenu</a></td>
            <td style={tableCellStyle}><a href='/StudentMenu'>Student menu</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentNotes1'>/StudentNotes1</a></td>
            <td style={tableCellStyle}><a href='/StudentNotes1'>Student NOTES1</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentNotesPage'>/StudentNotesPage</a></td>
            <td style={tableCellStyle}><a href='/StudentNotesPage'>Student notes page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentPeople'>/StudentPeople</a></td>
            <td style={tableCellStyle}><a href='/StudentPeople'>Student people</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentProfilePage'>/StudentProfilePage</a></td>
            <td style={tableCellStyle}><a href='/StudentProfilePage'>Student profile page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentResults'>/StudentResults</a></td>
            <td style={tableCellStyle}><a href='/StudentResults'>Student Results</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentSearch'>/StudentSearch</a></td>
            <td style={tableCellStyle}><a href='/StudentSearch'>Student search</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentSignup'>/StudentSignup</a></td>
            <td style={tableCellStyle}><a href='/StudentSignup'>Student signup</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentStream'>/StudentStream</a></td>
            <td style={tableCellStyle}><a href='/StudentStream'>Student Stream</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentSubmissionPage'>/StudentSubmissionPage</a></td>
            <td style={tableCellStyle}><a href='/StudentSubmissionPage'>Student SUBMISSION PAGE</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/StudentTools'>/StudentTools</a></td>
            <td style={tableCellStyle}><a href='/StudentTools'>Student tools</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherAddButtonInNotes'>/TeacherAddButtonInNotes</a></td>
            <td style={tableCellStyle}><a href='/TeacherAddButtonInNotes'>teacher Add button in notes</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherAttendance'>/TeacherAttendance</a></td>
            <td style={tableCellStyle}><a href='/TeacherAttendance'>teacher Attendance</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherChat'>/TeacherChat</a></td>
            <td style={tableCellStyle}><a href='/TeacherChat'>teacher chat</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherClassroom'>/TeacherClassroom</a></td>
            <td style={tableCellStyle}><a href='/TeacherClassroom'>teacher classroom</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherDashboard1'>/TeacherDashboard1</a></td>
            <td style={tableCellStyle}><a href='/TeacherDashboard1'>teacher dashboard 1</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherFirstPage'>/TeacherFirstPage</a></td>
            <td style={tableCellStyle}><a href='/TeacherFirstPage'>teacher first page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherLoginPage'>/TeacherLoginPage</a></td>
            <td style={tableCellStyle}><a href='/TeacherLoginPage'>teacher login page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherMenu'>/TeacherMenu</a></td>
            <td style={tableCellStyle}><a href='/TeacherMenu'>teacher menu</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherNotes1'>/TeacherNotes1</a></td>
            <td style={tableCellStyle}><a href='/TeacherNotes1'>teacher NOTES1</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherNotesPage'>/TeacherNotesPage</a></td>
            <td style={tableCellStyle}><a href='/TeacherNotesPage'>teacher notes page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherPeople'>/TeacherPeople</a></td>
            <td style={tableCellStyle}><a href='/TeacherPeople'>teacher people</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherPost'>/TeacherPost</a></td>
            <td style={tableCellStyle}><a href='/TeacherPost'>teacher post</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherPost1'>/TeacherPost1</a></td>
            <td style={tableCellStyle}><a href='/TeacherPost1'>teacher post</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherProfilePage'>/TeacherProfilePage</a></td>
            <td style={tableCellStyle}><a href='/TeacherProfilePage'>teacher profile page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherSearch'>/TeacherSearch</a></td>
            <td style={tableCellStyle}><a href='/TeacherSearch'>teacher search</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherSignup'>/TeacherSignup</a></td>
            <td style={tableCellStyle}><a href='/TeacherSignup'>teacher signup</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherStream'>/TeacherStream</a></td>
            <td style={tableCellStyle}><a href='/TeacherStream'>teacher Stream</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherStreamUploadPage'>/TeacherStreamUploadPage</a></td>
            <td style={tableCellStyle}><a href='/TeacherStreamUploadPage'>teacher Stream upload page</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherSubmissionPage'>/TeacherSubmissionPage</a></td>
            <td style={tableCellStyle}><a href='/TeacherSubmissionPage'>teacher SUBMISSION PAGE</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/TeacherTools'>/TeacherTools</a></td>
            <td style={tableCellStyle}><a href='/TeacherTools'>teacher tools</a></td>
          </tr>
</tbody>
      </table>
    </div>
  );
}