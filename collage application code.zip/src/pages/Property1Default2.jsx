import './Property1Default2.css'

export default function Property1Default2() {
  return (
    <div className="property-1-default">
      <span className="sign-up">
      Sign up
      </span>
      <div className="rectangle-42">
      </div>
    </div>
  )
}