import './StudentFirstPage.css'

export default function StudentFirstPage() {
  return (
    <div className="student-first-page">
      <div className="welcome-to-su">
      Welcome to S_U
      </div>
      <div className="let-access-all-work-from-here">
      LET ACCESS ALL WORK FROM HERE
      </div>
      <div className="login">
        <span className="login-1">
        Login
        </span>
        <div className="rectangle-42">
        </div>
      </div>
      <div className="signup">
        <span className="sign-up">
        Sign up
        </span>
        <div className="rectangle-421">
        </div>
      </div>
      <div className="image-3">
      </div>
    </div>
  )
}