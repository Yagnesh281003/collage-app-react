import './StudentTools.css'

export default function StudentTools() {
  return (
    <div className="student-tools">
      <div className="container-8">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-16">
            <div className="name">
            YB
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="rectangle-1">
      </div>
      <div className="container">
        <div className="menu">
          <div className="rectangle-5">
          </div>
        </div>
        <div className="tools">
        TOOLS
        </div>
        <div className="rectangle-2">
        </div>
      </div>
      <div className="container-19">
        <div className="search-1">
        </div>
        <div className="container-5">
          <div className="search">
          Search
          </div>
          <div className="container-4">
            <div className="search-2">
            </div>
          </div>
        </div>
      </div>
      <div className="container-12">
        <div className="container-11">
          <div className="computer-1">
          </div>
          <div className="rectangle-23">
          </div>
        </div>
        <div className="container-15">
          <div className="container-7">
            <div className="nottes">
              <div className="container-9">
                <div className="writing">
                  <div className="rectangle-3">
                  </div>
                </div>
              </div>
              <span className="notes">
              NOTES
              </span>
            </div>
            <div className="container-14">
              <div className="container-18">
                <div className="calendar">
                  <div className="rectangle-4">
                  </div>
                </div>
              </div>
              <span className="attendance">
              ATTENDANCE
              </span>
            </div>
          </div>
          <div className="container-6">
            <div className="container-10">
              <div className="image-4">
              </div>
            </div>
            <div className="container-13">
              <div className="results">
                <div className="rectangle">
                </div>
              </div>
            </div>
          </div>
          <div className="container-1">
            <span className="submission">
            SUBMISSION
            </span>
            <span className="results-1">
            RESULTS
            </span>
          </div>
          <div className="container-3">
            <div className="container-17">
              <div className="img-9">
              </div>
            </div>
            <div className="container-2">
              <div className="contact-form">
                <div className="rectangle-1">
                </div>
              </div>
            </div>
          </div>
          <div className="container-20">
            <div className="chat">
            CHAT
            </div>
            <div className="stream">
            Stream
            </div>
          </div>
          <div className="container-21">
            <div className="img-8">
            </div>
          </div>
          <span className="people">
          PEOPLE
          </span>
        </div>
      </div>
      <div className="rectangle-30">
      </div>
    </div>
  )
}