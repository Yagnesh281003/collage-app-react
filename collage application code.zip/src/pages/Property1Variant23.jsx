import './Property1Variant23.css'

export default function Property1Variant23() {
  return (
    <div className="property-1-variant-2">
      <span className="welcome-to-su">
      welcome to S_U
      </span>
    </div>
  )
}