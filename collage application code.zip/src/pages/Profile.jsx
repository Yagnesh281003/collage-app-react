import './Profile.css'

export default function Profile() {
  return (
    <div className="profile">
      <div className="ellipse-2">
      </div>
      <div className="container">
        <div className="name">
        NAME
        </div>
        <span className="abcd-123-gmail-com">
        abcd123@gmail.com
        </span>
      </div>
    </div>
  )
}