import './StudentDashboard1.css'

export default function StudentDashboard1() {
  return (
    <div className="student-dashboard-1">
      <div className="container-1">
        <div className="container">
          <div className="ellipse-3">
          </div>
          <div className="yb">
          YB
          </div>
        </div>
        <div className="group-10">
          <span className="menu">
          MENU
          </span>
        </div>
      </div>
      <div className="screenshot-202401231119021">
      </div>
      <div className="date-24-th-january-2024-time-0900-am-to-0100-pm-venue-aaryabhatta-auditorium">
      Date: 24th January, 2024<br />
      🕰️ Time: 09:00 AM to 01:00 PM<br />
      🏛️ Venue: Aaryabhatta Auditorium
      </div>
      <div className="img-2">
      </div>
      <div className="line-2">
      </div>
      <div className="screenshot-202401231124011">
      </div>
      <div className="date-24-th-january-2024-time-0900-am-to-0100-pm-venue-aaryabhatta-auditorium-1">
      Date: 24th January, 2024<br />
      🕰️ Time: 09:00 AM to 01:00 PM<br />
      🏛️ Venue: Aaryabhatta Auditorium
      </div>
      <div className="img-3">
      </div>
      <div className="line-3">
      </div>
      <div className="screenshot-2024012311190211">
      </div>
      <div className="screenshot-2024012311240111">
      </div>
      <div className="navigation-bar">
        <div className="container-2">
          <div className="rectangle-2">
          </div>
          <div className="rectangle-1">
          </div>
          <div className="rectangle">
          </div>
        </div>
        <img className="ellipse-6" src="assets/vectors/Ellipse63_x2.svg" />
        <div className="rectangle-3">
        </div>
      </div>
    </div>
  )
}