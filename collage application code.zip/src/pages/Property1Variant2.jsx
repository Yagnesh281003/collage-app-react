import './Property1Variant2.css'

export default function Property1Variant2() {
  return (
    <div className="property-1-variant-2">
      <div className="rectangle-38">
      </div>
      <div className="group-9">
        <div className="about">
        ABOUT
        </div>
        <div className="group-1">
          <div className="back-1">
          </div>
        </div>
      </div>
    </div>
  )
}