import './Property1Variant32.css'

export default function Property1Variant32() {
  return (
    <div className="property-1-variant-3">
      <div className="rectangle-501">
      </div>
      <span className="submit">
      Submit
      </span>
      <div className="rectangle">
      </div>
    </div>
  )
}