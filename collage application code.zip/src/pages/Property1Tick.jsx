import './Property1Tick.css'

export default function Property1Tick() {
  return (
    <div className="property-1-tick">
    </div>
  )
}