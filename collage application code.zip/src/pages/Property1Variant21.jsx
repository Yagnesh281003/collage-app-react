import './Property1Variant21.css'

export default function Property1Variant21() {
  return (
    <div className="property-1-variant-2">
      <span className="login">
      Login
      </span>
    </div>
  )
}