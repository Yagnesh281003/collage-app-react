import './StudentAttendance.css'

export default function StudentAttendance() {
  return (
    <div className="student-attendance">
      <div className="container-4">
        <div className="attendance">
        Attendance
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="container-2">
          <img className="ellipse-5" src="assets/vectors/Ellipse5_x2.svg" />
          <div className="container">
          09/03/2024
          </div>
        </div>
        <div className="container-1">
          <div className="oopu-ppp-pos-pwtpidt-pcgm-p">
          OOPU - P<br />
          PP - P<br />
          OS - P<br />
          W/T - P<br />
          IDT - P<br />
          CGM - P
          </div>
          <div className="line-5">
          </div>
          <span className="attendance-66">
          Attendance-6/6
          </span>
        </div>
      </div>
      <div className="line-4">
      </div>
      <div className="assignment-2">
        <div className="container-3">
          <img className="ellipse-51" src="assets/vectors/Ellipse55_x2.svg" />
          <div className="container-1">
          08/03/2024
          </div>
        </div>
        <div className="container">
          <div className="oopu-ppp-aos-pwtaidt-acgm-p">
          OOPU - P<br />
          PP - A<br />
          OS - P<br />
          W/T - A<br />
          IDT - A<br />
          CGM - P
          </div>
          <div className="line-6">
          </div>
          <span className="attendance-36">
          Attendance-3/6
          </span>
        </div>
      </div>
    </div>
  )
}