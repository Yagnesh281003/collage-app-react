import './TeacherAttendance.css'

export default function TeacherAttendance() {
  return (
    <div className="teacher-attendance">
      <div className="container-3">
        <div className="attendance">
        Attendance
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="container-5">
          <div className="container-1">
            <div className="back-31">
            </div>
          </div>
          <div className="container-10">
            <div className="back-32">
            </div>
          </div>
          <div className="container-6">
            <div className="back-4">
            </div>
          </div>
        </div>
        <div className="group-13">
          <div className="section">
          Section
          </div>
          <div className="back-3">
          </div>
        </div>
        <div className="container-11">
          <div className="container-7">
            <span className="present">
            Present
            </span>
          </div>
          <div className="container-2">
            <span className="absent">
            Absent
            </span>
          </div>
        </div>
        <div className="container">
          <div className="image-41">
          </div>
          <div className="image-22">
          </div>
          <div className="image-23">
          </div>
          <div className="image-24">
          </div>
          <div className="image-25">
          </div>
        </div>
        <div className="container-4">
          <div className="image-26">
          </div>
          <div className="image-27">
          </div>
          <div className="image-28">
          </div>
          <div className="image-29">
          </div>
          <div className="image-30">
          </div>
        </div>
        <div className="container-9">
          <div className="image-31">
          </div>
          <div className="image-32">
          </div>
          <div className="image-33">
          </div>
          <div className="image-34">
          </div>
          <div className="image-35">
          </div>
        </div>
        <div className="container-8">
          <div className="image-36">
          </div>
          <div className="image-37">
          </div>
          <div className="image-38">
          </div>
          <div className="image-39">
          </div>
          <div className="image-40">
          </div>
        </div>
        <div className="signup">
          <span className="sign-up">
          Submit
          </span>
          <div className="rectangle-42">
          </div>
        </div>
      </div>
    </div>
  )
}