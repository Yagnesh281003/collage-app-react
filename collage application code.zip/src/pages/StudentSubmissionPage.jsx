import './StudentSubmissionPage.css'

export default function StudentSubmissionPage() {
  return (
    <div className="student-submission-page">
      <div className="container-7">
        <div className="submission-task">
        Submission Task
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="container-6">
          <div className="problem-solving">
          Problem Solving
          </div>
          <div className="container-5">
            <div className="container-13">
              <img className="ellipse-5" src="assets/vectors/Ellipse51_x2.svg" />
              <div className="pp">
              PP
              </div>
            </div>
            <div className="container-21">
              <div className="clock">
                <div className="rectangle-1">
                </div>
              </div>
              <div className="container">
              09/10/2023
              </div>
            </div>
          </div>
          <div className="container-15">
            <div className="container-10">
              <div className="attach">
                <div className="rectangle">
                </div>
              </div>
              <span className="attach-file">
              Attach File
              </span>
            </div>
            <div className="container-19">
              <span className="write-something">
              Write Something
              </span>
            </div>
          </div>
          <div className="submit">
            <span className="submit-2">
            Submit
            </span>
          </div>
          <div className="container-9">
            <div className="tick">
              <div className="rectangle-2">
              </div>
            </div>
            <div className="mark-as-done">
            Mark as Done
            </div>
          </div>
        </div>
        <div className="remarks">
        Remarks
        </div>
        <div className="container-18">
          <div className="submitted-date">
          Submitted Date
          </div>
          <div className="container-1">
          07/03/2024
          </div>
        </div>
        <div className="container-8">
          <div className="verified-by">
          Verified by
          </div>
          <div className="abcdefg">
          ABCDEFG
          </div>
        </div>
        <div className="container-16">
          <div className="marks">
          Marks
          </div>
          <div className="container-2">
          10 / 10
          </div>
        </div>
      </div>
      <div className="line-4">
      </div>
      <div className="assignment-2">
        <div className="container-11">
          <div className="problem-solving-1">
          Problem Solving
          </div>
          <div className="container-14">
            <div className="container-4">
              <img className="ellipse-51" src="assets/vectors/Ellipse54_x2.svg" />
              <div className="oopu">
              Oopu
              </div>
            </div>
            <div className="container-22">
              <div className="clock-1">
                <div className="rectangle-3">
                </div>
              </div>
              <div className="container-5">
              09/10/2023
              </div>
            </div>
          </div>
          <div className="container-2">
            <div className="container-20">
              <div className="attach-1">
                <div className="rectangle-4">
                </div>
              </div>
              <span className="attach-file-1">
              Attach File
              </span>
            </div>
            <div className="container-3">
              <span className="write-something-1">
              Write Something
              </span>
            </div>
          </div>
          <div className="submit-1">
            <span className="submit-3">
            Submit
            </span>
          </div>
          <div className="container-17">
            <div className="tick-1">
              <div className="rectangle-5">
              </div>
            </div>
            <div className="mark-as-done-1">
            Mark as Done
            </div>
          </div>
        </div>
        <div className="remarks-1">
        Remarks
        </div>
        <div className="container">
          <div className="submitted-date-1">
          Submitted Date
          </div>
          <div className="container-4">
          09/03/2024
          </div>
        </div>
        <div className="container-12">
          <div className="verified-by-1">
          Verified by
          </div>
          <div className="abcdefg-1">
          ABCDEFG
          </div>
        </div>
        <div className="container-1">
          <div className="marks-1">
          Marks
          </div>
          <div className="container-3">
          10 / 10
          </div>
        </div>
      </div>
    </div>
  )
}