import './Property1Variant3.css'

export default function Property1Variant3() {
  return (
    <div className="property-1-variant-3">
      <div className="container">
        <div className="rectangle-3">
        </div>
        <div className="rectangle-2">
        </div>
        <div className="rectangle">
        </div>
      </div>
      <img className="ellipse-6" src="assets/vectors/Ellipse64_x2.svg" />
      <div className="rectangle-1">
      </div>
    </div>
  )
}