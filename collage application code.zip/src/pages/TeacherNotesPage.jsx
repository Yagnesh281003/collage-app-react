import './TeacherNotesPage.css'

export default function TeacherNotesPage() {
  return (
    <div className="teacher-notes-page">
      <div className="container-2">
        <div className="obm-752-notes-materials">
        OBM752 Notes / Materials
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-5">
        <div className="container-4">
          <div className="ellipse-5">
          </div>
          <div className="unit-1">
          Unit 1
          </div>
        </div>
        <div className="image-6">
        </div>
      </div>
      <div className="assignment-6">
        <div className="container-1">
          <div className="ellipse-51">
          </div>
          <div className="unit-2">
          Unit 2
          </div>
        </div>
        <div className="image-8">
        </div>
      </div>
      <div className="assignment-7">
        <div className="container-6">
          <div className="ellipse-52">
          </div>
          <div className="unit-3">
          Unit 3
          </div>
        </div>
        <div className="image-7">
        </div>
      </div>
      <div className="assignment-8">
        <div className="container-5">
          <div className="ellipse-53">
          </div>
          <div className="unit-4">
          Unit 4
          </div>
        </div>
        <div className="image-9">
        </div>
      </div>
      <div className="assignment-9">
        <div className="container">
          <div className="ellipse-54">
          </div>
          <div className="unit-5">
          Unit 5
          </div>
        </div>
        <div className="image-10">
        </div>
      </div>
      <div className="container-3">
        <div className="image-11">
        </div>
      </div>
    </div>
  )
}