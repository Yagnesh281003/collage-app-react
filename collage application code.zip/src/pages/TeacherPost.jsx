import './TeacherPost.css'

export default function TeacherPost() {
  return (
    <div className="teacher-post">
      <div className="back-2">
      </div>
      <div className="assignment-3">
        <div className="post">
        Post
        </div>
        <div className="container-1">
          <div className="attach">
            <div className="rectangle">
            </div>
          </div>
          <span className="attach-photo">
          Attach Photo
          </span>
        </div>
        <div className="container-2">
          <span className="write-description">
          Write Description
          </span>
        </div>
        <div className="container">
          <span className="mention-faculty">
          Mention Faculty
          </span>
        </div>
        <div className="submit">
          <span className="submit-1">
          Submit
          </span>
        </div>
      </div>
    </div>
  )
}