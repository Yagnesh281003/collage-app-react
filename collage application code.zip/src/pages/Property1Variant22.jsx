import './Property1Variant22.css'

export default function Property1Variant22() {
  return (
    <div className="property-1-variant-2">
      <span className="sign-up">
      Sign up
      </span>
    </div>
  )
}