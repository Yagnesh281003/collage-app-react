import './Property1Variant24.css'

export default function Property1Variant24() {
  return (
    <div className="property-1-variant-2">
      <div className="ellipse-2">
      </div>
      <div className="yb">
      YB
      </div>
    </div>
  )
}