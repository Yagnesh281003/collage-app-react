import './TeacherAddButtonInNotes.css'

export default function TeacherAddButtonInNotes() {
  return (
    <div className="teacher-add-button-in-notes">
      <div className="container-3">
        <div className="attach-files">
        Attach Files
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-3">
        <div className="unit-1">
        Unit 1
        </div>
        <div className="container-1">
          <div className="container-2">
            <div className="attach">
              <div className="rectangle">
              </div>
            </div>
            <span className="attach-file">
            Attach File
            </span>
          </div>
          <div className="container">
            <span className="write-something">
            Write Something
            </span>
          </div>
        </div>
        <div className="submit">
          <span className="submit-1">
          Submit
          </span>
        </div>
      </div>
    </div>
  )
}