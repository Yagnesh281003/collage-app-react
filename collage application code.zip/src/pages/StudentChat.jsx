import './StudentChat.css'

export default function StudentChat() {
  return (
    <div className="student-chat">
      <div className="container-1">
        <div className="chat">
        Chat
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="container-2">
          <span className="faculty-name">
          Faculty name 
          </span>
        </div>
        <div className="line-4">
        </div>
        <div className="container">
          <span className="write-something">
          Write Something
          </span>
        </div>
        <div className="submit">
          <span className="submit-1">
          Submit
          </span>
        </div>
      </div>
    </div>
  )
}