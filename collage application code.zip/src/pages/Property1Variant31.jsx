import './Property1Variant31.css'

export default function Property1Variant31() {
  return (
    <div className="property-1-variant-3">
      <div className="ellipse-8">
      </div>
      <img className="ellipse-7" src="assets/vectors/Ellipse71_x2.svg" />
      <span className="container">
      75%
      </span>
    </div>
  )
}