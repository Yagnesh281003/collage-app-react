import './StudentSignup.css'

export default function StudentSignup() {
  return (
    <div className="student-signup">
      <div className="back-11">
      </div>
      <div className="welcome-to-su">
      Welcome to S_U
      </div>
      <div className="let-access-all-work-from-here">
      LET ACCESS ALL WORK FROM HERE
      </div>
      <div className="container-2">
        <span className="full-name">
        Full Name
        </span>
      </div>
      <div className="container">
        <span className="email-address">
        Email Address
        </span>
      </div>
      <div className="container-1">
        <span className="create-password">
        Create Password
        </span>
      </div>
      <div className="re-enter-password">
      Re enter Password
      </div>
      <div className="signup">
        <span className="sign-up">
        Sign up
        </span>
        <div className="rectangle-42">
        </div>
      </div>
      <div className="image-2">
      </div>
      <div className="rectangle-8">
      </div>
    </div>
  )
}