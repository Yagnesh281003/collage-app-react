import './Property1Default5.css'

export default function Property1Default5() {
  return (
    <div className="property-1-default">
      <div className="container">
        <div className="rectangle-2">
        </div>
        <div className="rectangle-1">
        </div>
        <div className="rectangle">
        </div>
      </div>
      <img className="ellipse-6" src="assets/vectors/Ellipse6_x2.svg" />
      <div className="rectangle-3">
      </div>
    </div>
  )
}