import './TeacherClassroom.css'

export default function TeacherClassroom() {
  return (
    <div className="teacher-classroom">
      <div className="container-2">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-10">
            <div className="name">
            HR
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="rectangle-1">
      </div>
      <div className="container-1">
        <div className="menu">
          <div className="rectangle-1">
          </div>
        </div>
        <div className="classroom">
        Classroom<br />
        
        </div>
        <div className="rectangle">
        </div>
      </div>
      <div className="container-7">
        <div className="ce">
        CE
        </div>
        <div className="search-2">
        </div>
      </div>
      <div className="rectangle-34">
      </div>
      <div className="container-9">
        <div className="container-6">
          <div className="image-17">
          </div>
          <div className="rectangle-23">
          </div>
        </div>
        <div className="container-8">
          <div className="container">
            <div className="division-bbatch-1">
            Division:-B (Batch 1)
            </div>
            <div className="rectangle-331">
            </div>
            <div className="division-bbatch-2">
            Division:-B (Batch 2)
            </div>
            <div className="rectangle-42">
            </div>
            <div className="division-bbatch-3">
            Division:-B (Batch 3)
            </div>
            <div className="rectangle-43">
            </div>
            <div className="division-cbatch-1">
            Division:-C (Batch 1)
            </div>
            <div className="rectangle-44">
            </div>
            <div className="division-cbatch-2">
            Division:-C (Batch 2)
            </div>
            <div className="rectangle-45">
            </div>
            <div className="division-cbatch-3">
            Division:-C (Batch 3)
            </div>
            <div className="rectangle-46">
            </div>
            <div className="division-cbatch-4">
            Division:-C (Batch 4)
            </div>
            <div className="rectangle-47">
            </div>
          </div>
          <div className="line-4">
          </div>
          <div className="container-12">
            <div className="it">
            IT
            </div>
            <div className="container-4">
              <div className="back-4">
              </div>
            </div>
          </div>
          <div className="rectangle-36">
          </div>
          <div className="container-5">
            <div className="division-bbatch-11">
            Division:-B (Batch 1)
            </div>
            <div className="rectangle-49">
            </div>
            <div className="division-bbatch-21">
            Division:-B (Batch 2)
            </div>
            <div className="rectangle-50">
            </div>
            <div className="division-bbatch-31">
            Division:-B (Batch 3)
            </div>
            <div className="rectangle-55">
            </div>
            <div className="division-cbatch-11">
            Division:-C (Batch 1)
            </div>
            <div className="rectangle-54">
            </div>
            <div className="division-cbatch-21">
            Division:-C (Batch 2)
            </div>
            <div className="rectangle-53">
            </div>
            <div className="division-cbatch-31">
            Division:-C (Batch 3)
            </div>
            <div className="rectangle-52">
            </div>
            <div className="division-cbatch-41">
            Division:-C (Batch 4)
            </div>
            <div className="rectangle-51">
            </div>
          </div>
        </div>
      </div>
      <div className="container-3">
        <div className="search-1">
        </div>
        <div className="computer-2">
        </div>
      </div>
      <div className="container-11">
        <div className="back-3">
        </div>
      </div>
    </div>
  )
}