import './TeacherChat.css'

export default function TeacherChat() {
  return (
    <div className="teacher-chat">
      <div className="container-5">
        <div className="chat">
        Chat
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-6">
            <div className="name">
            YB
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="container-8">
          <span className="madam-please-send-notes-of-oopu">
          Madam please send notes of OOPU
          </span>
        </div>
        <div className="profile-1">
          <div className="ellipse-21">
          </div>
          <div className="container-3">
            <div className="name-1">
            SB
            </div>
            <span className="abcd-123-gmail-com-1">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="container-4">
          <span className="maam-ihave-problem-in-attendance">
          ma’am i have problem in attendance
          </span>
        </div>
        <div className="profile-2">
          <div className="ellipse-22">
          </div>
          <div className="container-2">
            <div className="name-2">
            TB
            </div>
            <span className="abcd-123-gmail-com-2">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="container">
          <span className="icant-open-my-google-classroom">
          I can’t open my google classroom 
          </span>
        </div>
        <div className="profile-3">
          <div className="ellipse-23">
          </div>
          <div className="container-1">
            <div className="name-3">
            AB
            </div>
            <span className="abcd-123-gmail-com-3">
            abcd123@gmail.com
            </span>
          </div>
        </div>
      </div>
      <div className="group-11">
        <span className="write-amessage">
        Write a message
        </span>
        <div className="container-7">
          <div className="image-12">
          </div>
        </div>
      </div>
    </div>
  )
}