import './Property1Default8.css'

export default function Property1Default8() {
  return (
    <div className="property-1-default">
      <div className="rectangle">
      </div>
    </div>
  )
}