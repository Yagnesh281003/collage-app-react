import './TeacherStreamUploadPage.css'

export default function TeacherStreamUploadPage() {
  return (
    <div className="teacher-stream-upload-page">
      <div className="container">
        <div className="stream">
        Stream
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-3">
            <div className="name">
            HR
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="container-2">
          <div className="attach">
            <div className="rectangle">
            </div>
          </div>
          <span className="attach-photo">
          Attach Photo
          </span>
        </div>
        <div className="container-1">
          <span className="write-description">
          Write Description
          </span>
        </div>
        <div className="submit">
          <span className="submit-1">
          Submit
          </span>
        </div>
      </div>
    </div>
  )
}