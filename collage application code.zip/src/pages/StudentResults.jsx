import './StudentResults.css'

export default function StudentResults() {
  return (
    <div className="student-results">
      <div className="container">
        <div className="results">
        Results
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="container-1">
        <span className="sem-1">
        Sem-1
        </span>
      </div>
      <div className="container-3">
        <span className="sem-2">
        Sem-2
        </span>
      </div>
      <div className="container-2">
        <span className="sem-3">
        Sem-3
        </span>
      </div>
    </div>
  )
}