import './Property1Variant26.css'

export default function Property1Variant26() {
  return (
    <div className="property-1-variant-2">
      <div className="ellipse-8">
      </div>
      <img className="ellipse-7" src="assets/vectors/Ellipse7_x2.svg" />
      <span className="container">
      75%
      </span>
    </div>
  )
}