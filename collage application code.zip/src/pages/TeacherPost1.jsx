import './TeacherPost1.css'

export default function TeacherPost1() {
  return (
    <div className="teacher-post">
      <div className="back-2">
      </div>
      <div className="assignment-2">
        <div className="profile">
          <img className="ellipse-2" src="assets/vectors/Ellipse22_x2.svg" />
          <div className="name">
          YB
          </div>
          <span className="abcd-123-gmail-com">
          abcd123@gmail.com
          </span>
        </div>
        <div className="container-2">
          <span className="madam-who-is-the-speaker-of-this-event">
          Madam , who is the speaker of this event?
          </span>
        </div>
        <div className="profile-1">
          <img className="ellipse-21" src="assets/vectors/Ellipse21_x2.svg" />
          <div className="name-1">
          YB
          </div>
          <span className="abcd-123-gmail-com-1">
          abcd123@gmail.com
          </span>
        </div>
        <div className="container-1">
          <span className="madam-please-share-more-details">
          Madam ,Please share more details
          </span>
        </div>
      </div>
      <div className="group-12">
        <span className="write-amessage">
        Write a message
        </span>
        <div className="container">
          <div className="image-12">
          </div>
        </div>
      </div>
    </div>
  )
}