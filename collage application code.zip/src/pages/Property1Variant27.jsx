import './Property1Variant27.css'

export default function Property1Variant27() {
  return (
    <div className="property-1-variant-2">
      <div className="rectangle-501">
      </div>
      <span className="submit">
      Submit
      </span>
    </div>
  )
}