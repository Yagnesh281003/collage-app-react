import './Property1Default1.css'

export default function Property1Default1() {
  return (
    <div className="property-1-default">
      <span className="login">
      Login
      </span>
      <div className="rectangle-42">
      </div>
    </div>
  )
}