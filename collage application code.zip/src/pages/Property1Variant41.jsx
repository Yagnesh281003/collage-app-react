import './Property1Variant41.css'

export default function Property1Variant41() {
  return (
    <div className="property-1-variant-4">
      <div className="ellipse-8">
      </div>
      <img className="ellipse-7" src="assets/vectors/Ellipse73_x2.svg" />
      <span className="container">
      75%
      </span>
    </div>
  )
}