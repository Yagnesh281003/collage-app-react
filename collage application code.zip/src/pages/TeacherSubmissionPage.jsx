import './TeacherSubmissionPage.css'

export default function TeacherSubmissionPage() {
  return (
    <div className="teacher-submission-page">
      <div className="container-5">
        <div className="submission-task">
        Submission Task
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-2">
        <div className="container-14">
          <div className="problem-solving-1">
          Problem Solving
          </div>
          <div className="container-22">
            <div className="container-20">
              <img className="ellipse-51" src="assets/vectors/Ellipse53_x2.svg" />
              <div className="pp">
              PP
              </div>
            </div>
            <div className="container-10">
              <div className="clock-1">
                <div className="rectangle-5">
                </div>
              </div>
              <div className="container-5">
              09/10/2023
              </div>
            </div>
          </div>
          <div className="container-6">
            <div className="container-11">
              <div className="attach">
                <div className="rectangle-1">
                </div>
              </div>
              <span className="attached">
              Attached
              </span>
            </div>
            <div className="container">
              <span className="pp-assign-2">
              22030507032257<br />
              PP Assign-2
              </span>
            </div>
          </div>
          <div className="submit">
            <span className="submit-2">
            Submit
            </span>
          </div>
          <div className="container-17">
            <div className="tick">
              <div className="rectangle-2">
              </div>
            </div>
            <div className="mark-as-done">
            Mark as Done
            </div>
          </div>
        </div>
        <div className="assignment-1">
          <div className="remarks-1">
          Remarks
          </div>
          <div className="container-15">
            <div className="submitted-date-1">
            Submitted Date
            </div>
            <div className="container-4">
            07/03/2024
            </div>
          </div>
          <div className="container-7">
            <div className="verified-by-1">
            Verified by
            </div>
            <div className="abcdefg-1">
            ABCDEFG
            </div>
          </div>
          <div className="container-4">
            <div className="marks-1">
            Marks
            </div>
            <div className="container-3">
            10 / 10
            </div>
          </div>
        </div>
        <div className="container-3">
          <div className="problem-solving">
          Problem Solving
          </div>
          <div className="container-2">
            <div className="container-21">
              <img className="ellipse-5" src="assets/vectors/Ellipse52_x2.svg" />
              <div className="oopu">
              Oopu
              </div>
            </div>
            <div className="container-9">
              <div className="clock">
                <div className="rectangle">
                </div>
              </div>
              <div className="container-2">
              09/10/2023
              </div>
            </div>
          </div>
          <div className="container-16">
            <div className="container-8">
              <div className="attach-1">
                <div className="rectangle-3">
                </div>
              </div>
              <span className="attached-1">
              Attached
              </span>
            </div>
            <div className="container-12">
              <span className="oopu-assign-2">
              22030507032257<br />
              OOPU Assign-2
              </span>
            </div>
          </div>
          <div className="submit-1">
            <span className="submit-3">
            Submit
            </span>
          </div>
          <div className="container-13">
            <div className="tick-1">
              <div className="rectangle-4">
              </div>
            </div>
            <div className="mark-as-done-1">
            Mark as Done
            </div>
          </div>
        </div>
        <div className="remarks">
        Remarks
        </div>
        <div className="container-19">
          <div className="submitted-date">
          Submitted Date
          </div>
          <div className="container-1">
          09/03/2024
          </div>
        </div>
        <div className="container-18">
          <div className="verified-by">
          Verified by
          </div>
          <div className="abcdefg">
          ABCDEFG
          </div>
        </div>
        <div className="container-1">
          <div className="marks">
          Marks
          </div>
          <div className="container">
          10 / 10
          </div>
        </div>
      </div>
      <div className="line-4">
      </div>
    </div>
  )
}