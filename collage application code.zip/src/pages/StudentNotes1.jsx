import './StudentNotes1.css'

export default function StudentNotes1() {
  return (
    <div className="student-notes-1">
      <div className="container-5">
        <div className="notes-materials">
        Notes / Materials
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="container-7">
        <div className="container-1">
          <div className="os">
          OS
          </div>
          <span className="obm-752">
          OBM752 
          </span>
        </div>
        <div className="container-3">
          <div className="oopu">
          OOPU
          </div>
          <span className="mg-8591">
          MG8591
          </span>
        </div>
        <div className="container">
          <div className="idt">
          IDT
          </div>
          <span className="it-8761">
          IT8761 
          </span>
        </div>
      </div>
      <div className="container-4">
        <div className="container-2">
          <div className="wt">
          W/T
          </div>
          <span className="it-8705">
          IT8705
          </span>
        </div>
        <div className="container-8">
          <div className="cgm">
          CGM
          </div>
          <span className="cs-8792">
          CS8792 
          </span>
        </div>
        <div className="cs-8791">
        CS8791 
        </div>
      </div>
      <div className="container-6">
        <span className="pp">
        PP
        </span>
      </div>
    </div>
  )
}