import './TeacherPeople.css'

export default function TeacherPeople() {
  return (
    <div className="teacher-people">
      <div className="container-1">
        <div className="people">
        People
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="container-5">
          <div className="teachers">
          Teachers
          </div>
          <div className="image-13">
          </div>
        </div>
        <div className="line-7">
        </div>
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-2">
            <div className="name">
            AB
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="profile-1">
          <div className="ellipse-21">
          </div>
          <div className="container-4">
            <div className="name-1">
            SB
            </div>
            <span className="abcd-123-gmail-com-1">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="profile-2">
          <div className="ellipse-22">
          </div>
          <div className="container-6">
            <div className="name-2">
            TB
            </div>
            <span className="abcd-123-gmail-com-2">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="profile-3">
          <div className="ellipse-23">
          </div>
          <div className="container-3">
            <div className="name-3">
            AB
            </div>
            <span className="abcd-123-gmail-com-3">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="container-7">
          <div className="students">
          Students
          </div>
          <div className="image-14">
          </div>
        </div>
        <div className="line-8">
        </div>
        <div className="profile-4">
          <div className="ellipse-24">
          </div>
          <div className="container">
            <div className="name-4">
            YB
            </div>
            <span className="abcd-123-gmail-com-4">
            abcd123@gmail.com
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}