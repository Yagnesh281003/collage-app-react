import './StudentMenu.css'

export default function StudentMenu() {
  return (
    <div className="student-menu">
      <div className="container-7">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-5">
            <div className="name">
            YB
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="rectangle-1">
      </div>
      <div className="container-10">
        <div className="menu">
          <div className="rectangle">
          </div>
        </div>
        <div className="main-menu">
        MAIN MENU
        </div>
        <div className="rectangle-1">
        </div>
      </div>
      <div className="container-2">
        <div className="container-12">
          <div className="search-1">
          </div>
          <div className="computer-1">
          </div>
        </div>
        <div className="container-3">
          <div className="container-6">
            <div className="search">
            Search
            </div>
            <div className="container-13">
              <div className="search-2">
              </div>
            </div>
          </div>
          <div className="container-15">
            <div className="about">
            ABOUT
            </div>
            <div className="container-1">
              <div className="back-1">
              </div>
            </div>
          </div>
          <div className="rectangle-27">
          </div>
          <div className="container-4">
            <div className="admission">
            ADMISSION
            </div>
            <div className="container-11">
              <div className="back-11">
              </div>
            </div>
            <span className="admission-1">
            ADMISSION
            </span>
          </div>
          <div className="rectangle-28">
          </div>
          <div className="container-8">
            <div className="academics">
            ACADEMICS<br />
            
            </div>
            <div className="container-14">
              <div className="back-12">
              </div>
            </div>
          </div>
          <div className="rectangle-29">
          </div>
          <div className="container-9">
            <div className="campus-life">
            CAMPUS LIFE
            </div>
            <div className="container">
              <div className="back-13">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}