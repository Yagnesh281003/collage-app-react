import './Property1Default6.css'

export default function Property1Default6() {
  return (
    <div className="property-1-default">
      <div className="ellipse-8">
      </div>
      <img className="ellipse-7" src="assets/vectors/Ellipse72_x2.svg" />
    </div>
  )
}