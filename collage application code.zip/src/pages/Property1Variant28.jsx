import './Property1Variant28.css'

export default function Property1Variant28() {
  return (
    <div className="property-1-variant-2">
      <div className="rectangle">
      </div>
    </div>
  )
}