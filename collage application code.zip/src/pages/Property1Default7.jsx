import './Property1Default7.css'

export default function Property1Default7() {
  return (
    <div className="property-1-default">
      <span className="submit">
      Submit
      </span>
    </div>
  )
}