import './TeacherLoginPage.css'

export default function TeacherLoginPage() {
  return (
    <div className="teacher-login-page">
      <div className="back-11">
      </div>
      <div className="welcome-to-su">
      Welcome to S_U
      </div>
      <div className="let-access-all-work-from-here">
      LET ACCESS ALL WORK FROM HERE
      </div>
      <div className="google-1">
      </div>
      <div className="container">
        <span className="email-address">
        Email Address
        </span>
      </div>
      <div className="container-1">
        <span className="password">
        Password
        </span>
      </div>
      <div className="forget-password">
      Forget Password
      </div>
      <div className="login">
        <span className="login-1">
        Login
        </span>
        <div className="rectangle-42">
        </div>
      </div>
      <div className="image-1">
      </div>
    </div>
  )
}