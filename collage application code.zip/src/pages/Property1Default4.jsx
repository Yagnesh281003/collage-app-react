import './Property1Default4.css'

export default function Property1Default4() {
  return (
    <div className="property-1-default">
      <div className="ellipse-2">
      </div>
      <div className="container">
        <div className="hi-yb">
        Hi YB
        </div>
        <span className="welcome-back">
        Welcome back
        </span>
      </div>
    </div>
  )
}