import './TeacherProfilePage.css'

export default function TeacherProfilePage() {
  return (
    <div className="teacher-profile-page">
      <div className="back-2">
      </div>
      <div className="my-profile">
      My Profile
      </div>
      <div className="container-16">
        <div className="container-15">
          <div className="ellipse-2">
          </div>
          <div className="container-2">
            <div className="hr">
            HR
            </div>
            <span className="container">
            210520201234
            </span>
          </div>
        </div>
        <div className="bell">
          <div className="rectangle">
          </div>
        </div>
      </div>
      <div className="container-7">
        <div className="container-10">
          <span className="department">
          DEPARTMENT :
          </span>
          <span className="btech-ce-1">
          B.Tech. CE
          </span>
        </div>
        <div className="container-1">
          <div className="id">
          ID :
          </div>
          <div className="container-2">
          1234567890
          </div>
        </div>
      </div>
      <div className="container-4">
        <span className="about">
        About
        </span>
        <div className="edit-1">
        Edit
        </div>
      </div>
      <div className="container-3">
        <span className="date-of-birth">
        Date of Birth
        </span>
        <span className="st-jan-2002">
        1st Jan 2002
        </span>
      </div>
      <div className="container-5">
        <span className="gender">
        Gender
        </span>
        <span className="male">
        MALE
        </span>
      </div>
      <div className="container-8">
        <span className="contact-details">
        Contact Details
        </span>
        <div className="edit">
        Edit
        </div>
      </div>
      <div className="container-13">
        <span className="contact-no">
        Contact no
        </span>
        <span className="container-1">
        123456790
        </span>
      </div>
      <div className="container">
        <span className="email">
        Email
        </span>
        <span className="abc-123-gmail-com">
        abc123@gmail.com
        </span>
      </div>
      <div className="container-9">
        <span className="address">
        Address
        </span>
        <span className="abc-street-defgh-ijklm-123456">
        12, abc street, defgh, ijklm - 123456.
        </span>
      </div>
      <div className="current-ongoing-courses">
      Current / Ongoing Courses
      </div>
      <div className="course-button">
        <span className="btech-ce">
        B.Tech CE
        </span>
        <div className="container-17">
          <div className="ellipse-3">
          </div>
          <div className="mortarboard">
            <div className="rectangle-1">
            </div>
          </div>
        </div>
      </div>
      <span className="ce">
      CE
      </span>
      <div className="department-of-engineering">
      Department of Engineering
      </div>
      <div className="container-11">
        <div className="calendar">
          <div className="rectangle-2">
          </div>
        </div>
        <div className="sep-2020-june-2024">
        Sep 2020 - June 2024
        </div>
      </div>
      <div className="passout-batch-210520201234">
      2024 Passout Batch | 210520201234
      </div>
      <div className="container-12">
        <span className="projects">
        Projects
        </span>
        <div className="add">
          <div className="add-new-1">
            <div className="plus">
              <div className="rectangle-3">
              </div>
            </div>
          </div>
          <div className="add-new">
          Add new
          </div>
        </div>
      </div>
      <div className="you-have-not-added-any-yet">
      You have not added any yet! 
      </div>
      <div className="container-18">
        <span className="certifications">
        Certifications
        </span>
        <div className="add-1">
          <div className="add-new-3">
            <div className="plus-1">
              <div className="rectangle-4">
              </div>
            </div>
          </div>
          <div className="add-new-2">
          Add new
          </div>
        </div>
      </div>
      <div className="you-have-not-added-any-yet-1">
      You have not added any yet! 
      </div>
      <div className="container-14">
        <span className="patents">
        Patents
        </span>
        <div className="add-2">
          <div className="add-new-5">
            <div className="plus-2">
              <div className="rectangle-5">
              </div>
            </div>
          </div>
          <div className="add-new-4">
          Add new
          </div>
        </div>
      </div>
      <div className="you-have-not-added-any-yet-2">
      You have not added any yet! 
      </div>
      <div className="container-6">
        <span className="extra-curricular-activities">
        Extra Curricular Activities
        </span>
        <div className="add-3">
          <div className="add-new-7">
            <div className="plus-3">
              <div className="rectangle-6">
              </div>
            </div>
          </div>
          <div className="add-new-6">
          Add new
          </div>
        </div>
      </div>
      <span className="you-have-not-added-any-yet-3">
      You have not added any yet! 
      </span>
    </div>
  )
}