import './Property1Default.css'

export default function Property1Default() {
  return (
    <div className="property-1-default">
      <span className="the-college-achristian-minority-institution-founded-by-rev-fr-jearulraj-situated-in-the-western-part-of-chennai-at-palanchoor-5-kms-from-poonamalle-on-the-chennai-bangalore-national-highway-in-asprawling-campus-of-55-acre-land-dmice-is-awell-established-institution-committed-to-impart-education-cum-discipline-to-the-society-since-2001-the-mission-of-dmi-college-of-engineering-is-to-sustain-acommunity-of-individuals-who-are-dedicated-to-the-achievement-of-excellence-and-who-share-avision-related-to-engineering-management">
      The college, a Christian minority institution founded by Rev. Fr. J.E.Arulraj, situated in the western part of Chennai at Palanchoor 5 kms from Poonamalle on the Chennai-Bangalore National Highway in a sprawling campus of 55 acre land. DMICE is a well established institution committed to impart education cum discipline to the society since 2001.<br />
      The mission of DMI College of Engineering is to sustain a community of individuals who are dedicated to the achievement of excellence and who share a vision related to Engineering &amp; Management.
      </span>
      <div className="container">
        <div className="about">
        ABOUT
        </div>
        <div className="group-1">
          <div className="back-1">
          </div>
        </div>
      </div>
    </div>
  )
}