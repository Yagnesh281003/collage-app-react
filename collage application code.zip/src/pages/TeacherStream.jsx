import './TeacherStream.css'

export default function TeacherStream() {
  return (
    <div className="teacher-stream">
      <div className="container-1">
        <div className="stream">
        Stream
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="assignment-1">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-2">
            <div className="name">
            MK
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="rectangle-51">
        </div>
        <div className="profile-1">
          <div className="ellipse-21">
          </div>
          <div className="container">
            <div className="name-1">
            AB
            </div>
            <span className="abcd-123-gmail-com-1">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="rectangle-52">
        </div>
        <div className="image-12">
        </div>
      </div>
    </div>
  )
}