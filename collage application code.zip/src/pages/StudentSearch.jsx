import './StudentSearch.css'

export default function StudentSearch() {
  return (
    <div className="student-search">
      <div className="container-8">
        <div className="profile">
          <div className="ellipse-2">
          </div>
          <div className="container-2">
            <div className="name">
            YB
            </div>
            <span className="abcd-123-gmail-com">
            abcd123@gmail.com
            </span>
          </div>
        </div>
        <div className="back-2">
        </div>
      </div>
      <div className="rectangle-1">
      </div>
      <div className="container-3">
        <div className="menu">
          <div className="rectangle-1">
          </div>
        </div>
        <div className="search">
        SEARCH
        </div>
        <div className="rectangle">
        </div>
      </div>
      <div className="container-6">
        <div className="search-1">
        </div>
        <div className="container-7">
          <div className="search-1">
          Search
          </div>
          <div className="container-5">
            <div className="search-2">
            </div>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="container-1">
          <div className="computer-1">
          </div>
        </div>
        <div className="container-4">
          <div className="most-searches">
          Most Searches
          </div>
          <div className="group-5">
            <span className="events">
            events
            </span>
          </div>
        </div>
        <div className="group-7">
          <span className="sports">
          Sports
          </span>
        </div>
        <div className="group-8">
          <span className="admissions">
          Admissions
          </span>
        </div>
      </div>
      <div className="rectangle-30">
      </div>
    </div>
  )
}